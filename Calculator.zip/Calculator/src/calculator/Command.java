/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.*;
import java.io.*;

/**
 *
 * @author hayde
 */
public class Command {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        while (true) {
            System.out.print("Please enter an equation.(type 'quit' to stop.)");
            String eqn = scan.nextLine();
            if (eqn.equals("quit")) {
                break;
            }
            try { 
                Calculator.checkValidity(eqn);
                double ans = Calculator.solve(Calculator.toBinaryTree(eqn));
                System.out.println(eqn + " = " + ans);
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }
}

class Calculator {
    
   /* 
    * uses the given eqn and rewrites it as a BST object which it will return
    *
    * @Exception - throws an exception if the equation is incorrectly written
    * @param eqn - a math equation that a user will want solved
    * @return BST - a simplified version of the given math equation which 
    * can be solved using a preorder traversal like you would through a binary tree
    */
    public static BST toBinaryTree(String eqn) throws Exception {
        BST order = new BST();
        String val = "";
        eqn = eqn.replace(" ", "");
        char prev = 'a';
        for (int i = 0; i < eqn.length(); i++) {
            char cur = eqn.charAt(i);
            char next = 'a';
            if (i < eqn.length() - 1) {
                next = eqn.charAt(i + 1);
            }
            if (i > 0) {
                prev = eqn.charAt(i - 1);
            }
            
            if (cur == '(') {
                eqn = eqn.substring(0, i) + simplify(eqn.substring(i + 1));
                i--;
            } else if (cur == ')') {
                val = "";
            }  else if (Character.isLetter(cur) || val.contains("log")) {
                val += Character.toLowerCase(cur);
                if (eqn.length() < 2) {
                    val = "";
                } else if ((val.equals("sin") || val.equals("cos") || 
                            val.equals("tan") || val.equals("cot") || 
                            val.equals("ln") || val.equals("log10") || (val.contains("log") && next == '('))) {
                    Node operator = new Node(1, val);
                    BST root = new BST(operator, new BST(new Node(0, "0"), null, null), null);
                    order = order.add(root);
                    val = "";
                } else if (val.length() >= 5){
                    throw new Exception("Not a valid trig or log function.");
                }
            }   else if (Character.isDigit(cur) || (cur == '.')) {
                val += cur;
                if ((next == '.' && val.contains(".")) || (cur == '.' && next == '-')) {
                    throw new Exception("cannot use multiple decimals in a single number.");
                } else if (!Character.isDigit(next) && next != '.') {
                    Node operand = new Node(0, val);
                    BST root = new BST(operand, null, null);
                    order = order.add(root);
                    val = "";
                }
            } else if (cur == '-' && !Character.isDigit(prev)) {
                if (val.contains("-")) {
                    val = "";
                } else {
                    val += cur;
                }
            } else if (cur == '+' || cur == '-') {
                Node operator = new Node(4, Character.toString(cur));
                BST root = new BST(operator, null, null);
                order = order.add(root);
            } else if (cur == '*' || cur == '/') {
                Node operator = new Node(3, Character.toString(cur));
                BST root = new BST(operator, null, null);
                order = order.add(root);
            } else if (cur == '^') {
                Node operator = new Node(2, Character.toString(cur));
                BST root = new BST(operator, null, null);
                order = order.add(root);
            }    
        }
        return order;
    }
    
   /*
    * simplifies the given eqn and then returns the simplified version.
    *
    * @Exception - throws an exception if the equation cannot be computated 
    * of if the quations is incorrectly parenthesed
    * @param eqn - a math equation
    * @return string - a simplified version of the given math equation
    */
    public static String simplify(String eqn) throws Exception{
        String subEqn = "";
        for (int i = 0; i < eqn.length(); i++) {
            if (eqn.charAt(i) == ')') {
                return Double.toString(solve(toBinaryTree(subEqn))) + eqn.substring(i + 1);                
            } else if (eqn.charAt(i) == '('){
                eqn = eqn.substring(0, i) + simplify(eqn.substring(i + 1));
                i--;
            } else if (i != eqn.length() - 1){
                subEqn += eqn.charAt(i);
            } else {
                throw new Exception("Missing a closing parenthese");
            }
        }
        return subEqn;
    }
    
   /*
    * solves the given equation inside the BST object
    *
    * @Exception - throws an exception if there is no BST object or if 
    * the children of the parent node cannot be solved
    * @param root - a part of the overall equation that is being solved
    * @return double - returns the answer to the equation in the given root
    */
    public static double solve(BST root) throws Exception {
        if (root.getCurrent() == null) {
            throw new Exception("Missing an operand");
        }
        Node current = root.getCurrent();
        if (current.priority == 0) {
            return Double.parseDouble(current.val);
        } else if (current.val.equals("+")) {
            return solve(root.getLeft()) + solve(root.getRight());
        } else if (current.val.equals("-")) {
            return solve(root.getLeft()) - solve(root.getRight());
        } else if (current.val.equals("*")) {
            return solve(root.getLeft()) * solve(root.getRight());
        } else if (current.val.equals("/")) {
            if (solve(root.getRight()) == 0) {
                throw new Exception("cannot divide by zero");
            }
            return solve(root.getLeft()) / solve(root.getRight());
        } else if (current.val.equals("^")) {
            return Math.pow(solve(root.getLeft()),solve(root.getRight()));
        } else if (current.val.equals("sin")) {
            return Math.sin(solve(root.getRight()));
        } else if (current.val.equals("cos")) {
            return Math.cos(solve(root.getRight()));
        } else if (current.val.equals("tan")) {
            return Math.tan(solve(root.getRight()));
        } else if (current.val.equals("cot")) {
            return 1/Math.tan(solve(root.getRight()));
        } else if (current.val.equals("ln")) {
            double num = Double.parseDouble(root.getRight().getCurrent().val);
            if (num < 0) {
                throw new Exception("cannot evaluate imaginary numbers.");
            } else {
                return Math.log(solve(root.getRight()));
            }
        } else if (current.val.equals("log10") || current.val.equals("log")) {
            double num = Double.parseDouble(root.getRight().getCurrent().val);
            if (num < 0) {
                throw new Exception("cannot evaluate imaginary numbers.");
            } else {
                return Math.log10(solve(root.getRight()));
            }
        } else {
            throw new Exception("Not a valid operand or function.");
        }
    }
    
   /*
    * checks that the given eqn has all the needed parentheses and that there
    * are no numbers in invalid places.
    *
    * @Exception - throws an exception if the method finds an error with 
    * the given eqn
    * @param eqn - the equation that is being checked.
    */
    public static void checkValidity(String eqn) throws Exception {
        boolean pass = true;
        int parenths = 0;
        if (eqn.length() == 0) {
            pass = false;
        } else if (eqn.charAt(0) == '(') {
            parenths++;
        } else if (eqn.charAt(0) == ')') {
            pass = false;
        }
        for (int i = 1; i < eqn.length(); i++) {
            char prev = eqn.charAt(i-1);
            char cur = eqn.charAt(i);
            if (cur == '(') {
                parenths++;
                if (Character.isDigit(prev)) {
                    if (eqn.substring(0, i).length() >= 5) {
                        if (!eqn.substring(i-5, i).equals("log10")) {
                            pass = false;
                        }
                    } else {
                        pass = false;
                    } 
                }
            } else if (cur == ')') {
                parenths--;
                if (parenths < 0) {
                    pass = false;
                }
                if (i < eqn.length() - 1) {
                    if (Character.isDigit(eqn.charAt(i+1))) {
                        pass = false;
                    }
                }
            }
            if (i < eqn.length() - 1) {
                if (eqn.substring(i - 1, i + 1).equals("ln") && eqn.charAt(i + 1) != '(') {
                    pass = false;
                }
            }
            if (i < eqn.length() - 2) {
                if ((eqn.substring(i - 1, i + 2).equals("sin") 
                        || eqn.substring(i - 1, i + 2).equals("cos") 
                        || eqn.substring(i - 1, i + 2).equals("tan") 
                        || eqn.substring(i - 1, i + 2).equals("cot")) && eqn.charAt(i + 2) != '(') {
                    pass = false;
                }
            }
            if (i < eqn.length() - 4) {
                if (eqn.substring(i - 1, i + 4).equals("log10") && eqn.charAt(i + 4) != '(') {
                    pass = false;
                }
            }
        }
        if (!pass || parenths != 0) {
            throw new Exception("This is not a valid equation.");
        }
    }
}

/*
 * a binary tree object that is used to solve equation in the correct order.
 *
 * Note for graders wondering why I didn't use java's binary tree class.
 * I had issues getting it to initialize
 */
class BST {
    // the current Node object that the tree is looking at
    private Node current;
    // the left child object of the current object
    private BST left;
    // the right child object of the current object
    private BST right;
    
    // constructor - creates the BST object while passing the info for all three
    // of its fields
    public BST(Node current, BST left, BST right) {
        this.current = current;
        this.left = left;
        this.right = right;
    }
    
    // a basic constructor that requires no input;
    public BST() {}
    
   /*
    * @return BST - return the right child of the BST
    */
    public BST getRight() {
        return right;
    }
    
    /*
    * @return BST - return the left child of the BST
    */
    public BST getLeft() {
        return left;
    }
    
    /*
    * @return Node - returns the Node object of the BST
    */
    public Node getCurrent() {
        return current;
    }
    
   /*
    * adds the given root to the BST
    *
    * @param root - a new BST that needs to be added to the BST using the root's
    * current Node's priority and the main BST object's current Node's priority
    * @return BST - returns the new BST that was created
    */
    public BST add(BST root) {
        if (current == null && root.getCurrent().val.equals("-")) {
            BST zero = new BST(new Node(0, "0"), null, null);
            return new BST(root.getCurrent(), zero, null);
        } else if (current == null) {
            return root;
        } else if (root.getCurrent().priority == 1 && root.getCurrent().val.equals("-")) {
            root.setRight(this);
            return root;
        } else if (current.priority <= root.getCurrent().priority) {
            root.setLeft(this);
            return root;
        } else if (right == null) {
            return new BST(this.current, this.getLeft(), root);
        } else {
            right = right.add(root);
            return this;
        }
    }
    
    // returns the BST object as a string.
    // This is basically used to print out the equation again.
    // only used in testing.
    public String toString() {
        if (current == null) {
            return "";
        } else if (right == null && left == null) {
            return current.val;
        } else if (right == null) {
            return left.toString() + current.val; 
        } else if (left == null) {
            return current.val + right.toString();
        } else {
            return left.toString()+current.val+right.toString();
        }
    }
     
   /*
    * sets the right node equal to the given node
    *
    * @param node - the new child BST
    * @return BST - the child BST that was just set
    */
    public BST setRight(BST node) {
        right = node;
        return right;
    }
    
    /*
    * sets the left node equal to the given node
    *
    * @param node - the new child BST
    * @return BST - the child BST that was just set
    */
    public BST setLeft(BST node) {
        left = node;
        return left;
    }
}

// An object used to give parts of an equation their priority and value which 
// should simulate an order of operations.
class Node {
    // the priority in which the Node should be solved
    public int priority;
    // the value of the node that will be used to solve the equation
    public String val;
    
    // constructs a Node object by passing in its fields as parameters.
    public Node(int priority, String val) {
        this.priority = priority;
        this.val = val;
    }
}