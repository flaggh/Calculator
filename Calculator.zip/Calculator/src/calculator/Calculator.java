/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;
import java.util.*;
import java.io.*;

/**
 *
 * @author hayde
 */
public class Calculator {

    public static void main(String[] args) {
        simplify("a");
        System.out.println("1 + 1 * 1 = " + solve(toBinaryTree("1+1*1")));
        System.out.println("1 = " + solve(toBinaryTree("1")));
        System.out.println("1 * 1 - 1 = " + solve(toBinaryTree("1*1-1")));
        System.out.println("1 / 1.23 + 1 * 1 = " + solve(toBinaryTree("1/1.23+1*1")));
        System.out.println("3 ^ 2 = " + solve(toBinaryTree("3^2")));
        System.out.println("2 ^ 3 = " + solve(toBinaryTree("2^3")));
        System.out.println("1 / 1.23 + 1 * 2 ^ 0 = " + solve(toBinaryTree("1/1.23+1*2^0")));
        System.out.println("(1 + 1) = " + solve(toBinaryTree("(1+1)")));
        System.out.println("(1 + 1) * 2 = " + solve(toBinaryTree("(1+1)*2")));
        System.out.println("sin(1) = " + solve(toBinaryTree("sin(1)")));
        System.out.println("cos(1) = " + solve(toBinaryTree("cos(1)")));
        System.out.println("tan(1) = " + solve(toBinaryTree("tan(1)")));
        System.out.println("-1 = " + solve(toBinaryTree("-1")));
        System.out.println("1 / -1 = " + solve(toBinaryTree("1/-1")));
        System.out.println("ln(1) = " + solve(toBinaryTree("ln(1)")));
    }
    
    public static BST toBinaryTree(String eqn) {
        BST order = new BST();
        String val = "";
        while (eqn.length() > 0) {
            Character current = eqn.charAt(0);
            Character next = 'a';
            boolean checkneg = false;
            if (eqn.length() > 1) {
                next = eqn.charAt(1);
            } 
            if (current == '(') {
                eqn = " " + simplify(eqn);
            } else if ((Character.isDigit(current) || 
                            (current.equals('.') && !val.contains("."))) && !val.equals("log")) {
                val += current;
                if (!Character.isDigit(next) && 
                            !(next.equals('.') && !val.contains("."))) {
                    Node operand = new Node(0, val);
                    BST root = new BST(operand, null, null);
                    order = order.add(root);;
                    val = "";
                }
            } else if (current == '+' || current == '-') {
                Node operator = new Node(4, Character.toString(current));
                BST root = new BST(operator, null, null);
                order = order.add(root);
                checkneg = true;
            } else if (current == '*' || current == '/') {
                Node operator = new Node(3, Character.toString(current));
                BST root = new BST(operator, null, null);
                order = order.add(root);
                checkneg = true;
            } else if (current == '^') {
                Node operator = new Node(2, Character.toString(current));
                BST root = new BST(operator, null, null);
                order = order.add(root);
                checkneg = true;
            } else if (Character.isLetter(current)) {
                val += Character.toLowerCase(current);
                if (val.length() <= 3 && eqn.charAt(1) == '(') {
                    Node operator = new Node(1, val);
                    BST root = new BST(operator, null, null);
                    order = order.add(root);
                    order = order.add(new BST(new Node(0, "0"), null, null));
                    val = "";
                } else if (val.length() == 3 && eqn.charAt(1) != '('){
                    System.out.println("This equation is not valid.2");
                    break;

                }
            }
            if (checkneg) {
                Character neg = eqn.charAt(1);
                if (neg.equals('-')) {
                    BST zero = new BST(new Node(0, "0"), null, null);
                    BST bin = new BST(new Node(1, "-"), zero, null);
                    order = order.add(bin);
                    if (eqn.length() > 1) {
                        eqn = eqn.substring(1);
                    } else {
                        eqn = "";
                    }
                }
            }
            if (eqn.length() > 1) {
                eqn = eqn.substring(1);
            } else {
                eqn = "";
            }
        }
        return order;
    }
    
    public static String simplify(String eqn) {
        eqn = eqn.substring(1);
        String subEqn = "";
        for (int i = 0; i < eqn.length(); i++) {
            if (eqn.charAt(i) == ')') {
                return Double.toString(solve(toBinaryTree(subEqn))) + eqn.substring(i + 1);
            } else if (eqn.charAt(i) == '('){
                subEqn = simplify(eqn.substring(i));
            } else {
                subEqn += eqn.charAt(i);
            }
        }
        return subEqn;
    }
    
    public static double solve(BST root) {
        Node current = root.getCurrent();
        if (current.priority == 0) {
            return Double.parseDouble(current.val);
        } else if (current.val.equals("+")) {
            return solve(root.getLeft()) + solve(root.getRight());
        } else if (current.val.equals("-")) {
            return solve(root.getLeft()) - solve(root.getRight());
        } else if (current.val.equals("*")) {
            return solve(root.getLeft()) * solve(root.getRight());
        } else if (current.val.equals("/")) {
            return solve(root.getLeft()) / solve(root.getRight());
        } else if (current.val.equals("^")) {
            return Math.pow(solve(root.getLeft()),solve(root.getRight()));
        } else if (current.val.equals("sin")) {
            return Math.sin(solve(root.getRight()));
        } else if (current.val.equals("cos")) {
            return Math.cos(solve(root.getRight()));
        } else if (current.val.equals("tan")) {
            return Math.tan(solve(root.getRight()));
        } else if (current.val.equals("cot")) {
            return 1/Math.tan(solve(root.getRight()));
        } else if (current.val.equals("ln")) {
            return Math.log(solve(root.getRight()));
        } else {
            System.out.println("This is not a valid equation.3");
            return 0;
        }
    }
    
}