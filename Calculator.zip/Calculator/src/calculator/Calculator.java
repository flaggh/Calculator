/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;
import java.util.*;
import java.io.*;

/**
 *
 * @author hayde
 */
public class Calculator {
    
    public static BST toBinaryTree(String eqn) throws Exception {
        BST order = new BST();
        String val = "";
        while (eqn.length() > 0) {
            Character current = eqn.charAt(0);
            Character next = 'a';
            boolean checkneg = false;
            if (eqn.length() > 1) {
                next = eqn.charAt(1);
            } 
            if (current == '(') {
                eqn = " " + simplify(eqn);
            } else if ((Character.isDigit(current) || 
                            (current.equals('.') && !val.contains("."))) && !val.contains("log")) {
                val += current;
                if (!Character.isDigit(next) && 
                            !(next.equals('.') && !val.contains("."))) {
                    Node operand = new Node(0, val);
                    BST root = new BST(operand, null, null);
                    order = order.add(root);;
                    val = "";
                }
            } else if (current == '+' || current == '-') {
                Node operator = new Node(4, Character.toString(current));
                BST root = new BST(operator, null, null);
                order = order.add(root);
                checkneg = true;
            } else if (current == '*' || current == '/') {
                Node operator = new Node(3, Character.toString(current));
                BST root = new BST(operator, null, null);
                order = order.add(root);
                checkneg = true;
            } else if (current == '^') {
                Node operator = new Node(2, Character.toString(current));
                BST root = new BST(operator, null, null);
                order = order.add(root);
                checkneg = true;
            } else if (Character.isLetter(current) || val.contains("log")) {
                val += Character.toLowerCase(current);
                if (eqn.length() < 2) {
                    val = "";
                } else if (val.length() <= 5 && eqn.charAt(1) == '(') {
                    Node operator = new Node(1, val);
                    BST root = new BST(operator, null, null);
                    order = order.add(root);
                    order = order.add(new BST(new Node(0, "0"), null, null));
                    val = "";
                } else if (val.length() == 5 && eqn.charAt(1) != '('){
                    System.out.println("This equation is not valid.");
                    break;
                }
            }
            if (checkneg) {
                Character neg = eqn.charAt(1);
                if (neg.equals('-')) {
                    BST zero = new BST(new Node(0, "0"), null, null);
                    BST bin = new BST(new Node(1, "-"), zero, null);
                    order = order.add(bin);
                    if (eqn.length() > 1) {
                        eqn = eqn.substring(1);
                    } else {
                        eqn = "";
                    }
                }
            }
            if (eqn.length() > 1) {
                eqn = eqn.substring(1);
            } else {
                eqn = "";
            }
        }
        return order;
    }
    
    public static String simplify(String eqn) throws Exception{
        eqn = eqn.substring(1);
        String subEqn = "";
        for (int i = 0; i < eqn.length(); i++) {
            if (eqn.charAt(i) == ')') {
                return Double.toString(solve(toBinaryTree(subEqn))) + eqn.substring(i + 1);                
            } else if (eqn.charAt(i) == '('){
                subEqn = Double.toString(solve(toBinaryTree(eqn.substring(i+1))));
            } else if (i != eqn.length() - 1){
                subEqn += eqn.charAt(i);
            } else {
                throw new Exception("Solve");
            }
        }
        return subEqn;
    }
    
    public static double solve(BST root) throws Exception {
        if (root.getCurrent() == null) {
            throw new ArithmeticException("Not a valid Equation.");
        }
        Node current = root.getCurrent();
        if (current.priority == 0) {
            return Double.parseDouble(current.val);
        } else if (current.val.equals("+")) {
            return solve(root.getLeft()) + solve(root.getRight());
        } else if (current.val.equals("-")) {
            return solve(root.getLeft()) - solve(root.getRight());
        } else if (current.val.equals("*")) {
            return solve(root.getLeft()) * solve(root.getRight());
        } else if (current.val.equals("/")) {
            return solve(root.getLeft()) / solve(root.getRight());
        } else if (current.val.equals("^")) {
            return Math.pow(solve(root.getLeft()),solve(root.getRight()));
        } else if (current.val.equals("sin")) {
            return Math.sin(solve(root.getRight()));
        } else if (current.val.equals("cos")) {
            return Math.cos(solve(root.getRight()));
        } else if (current.val.equals("tan")) {
            return Math.tan(solve(root.getRight()));
        } else if (current.val.equals("cot")) {
            return 1/Math.tan(solve(root.getRight()));
        } else if (current.val.equals("ln")) {
            return Math.log(solve(root.getRight()));
        } else if (current.val.equals("log10")) {
            return Math.log10(solve(root.getRight()));
        } else {
            System.out.println("This is not a valid equation.3");
            return 0;
        }
    }
    
    public static void checkValidity(String eqn) throws Exception {
        boolean pass = true;
        int parenths = 0;
        if (eqn.charAt(0) == '(') {
            parenths++;
        } else if (eqn.charAt(0) == ')') {
            pass = false;
        }
        for (int i = 1; i < eqn.length(); i++) {
            char prev = eqn.charAt(i-1);
            char cur = eqn.charAt(i);
            if (cur == '(') {
                parenths++;
                if (Character.isDigit(prev)) {
                    pass = false;
                }
            } else if (cur == ')') {
                parenths--;
                if (parenths < 0) {
                    pass = false;
                }
                if (i < eqn.length() - 1) {
                    if (Character.isDigit(eqn.charAt(i+1))) {
                        pass = false;
                    }
                }
            }
        }
        if (!pass || parenths != 0) {
            throw new Exception();
        }
    }
}