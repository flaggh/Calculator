/*
 * Name: Hayden Flagg
 * Class: CS 480 - Advanced Software Engineering
 * Assignment: Lab 3
 *
 * Honor Code: I pledge that this is my own original work and that I have not
 * received any unauthorized support with this lab.
 */

package calculator;
import java.util.*;
import java.io.*;

/**
 *
 * @author hayden flagg
 */

// a class used to solve math equations like an actual calculator.
// can solve equations using +, -, *, /, ^, sin, cos, tan, cot, ln,
// log10, and parentheses.
public class Calculator {
    
   /* 
    * uses the given eqn and rewrites it as a BST object which it will return
    *
    * @Exception - throws an exception if the equation is incorrectly written
    * @param eqn - a math equation that a user will want solved
    * @return BST - a simplified version of the given math equation which 
    * can be solved using a preorder traversal like you would through a binary tree
    */
    public static BST toBinaryTree(String eqn) throws Exception {
        BST order = new BST();
        String val = "";
        eqn = eqn.replace(" ", "");
        char prev = 'a';
        for (int i = 0; i < eqn.length(); i++) {
            char cur = eqn.charAt(i);
            char next = 'a';
            if (i < eqn.length() - 1) {
                next = eqn.charAt(i + 1);
            }
            if (i > 0) {
                prev = eqn.charAt(i - 1);
            }
            
            if (cur == '(') {
                eqn = eqn.substring(0, i) + simplify(eqn.substring(i + 1));
                i--;
            } else if (cur == ')') {
                val = "";
            }  else if (Character.isLetter(cur) || val.contains("log")) {
                val += Character.toLowerCase(cur);
                if (eqn.length() < 2) {
                    val = "";
                } else if ((val.equals("sin") || val.equals("cos") || 
                            val.equals("tan") || val.equals("cot") || 
                            val.equals("ln") || val.equals("log10") || (val.contains("log") && next == '('))) {
                    Node operator = new Node(1, val);
                    BST root = new BST(operator, new BST(new Node(0, "0"), null, null), null);
                    order = order.add(root);
                    val = "";
                } else if (val.length() >= 5){
                    throw new Exception("Not a valid trig or log function.");
                }
            }   else if (Character.isDigit(cur) || (cur == '.')) {
                val += cur;
                if ((next == '.' && val.contains(".")) || (cur == '.' && next == '-')) {
                    throw new Exception("cannot use multiple decimals in a single number.");
                } else if (!Character.isDigit(next) && next != '.') {
                    Node operand = new Node(0, val);
                    BST root = new BST(operand, null, null);
                    order = order.add(root);
                    val = "";
                }
            } else if (cur == '-' && !Character.isDigit(prev)) {
                if (val.contains("-")) {
                    val = "";
                } else {
                    val += cur;
                }
            } else if (cur == '+' || cur == '-') {
                Node operator = new Node(4, Character.toString(cur));
                BST root = new BST(operator, null, null);
                order = order.add(root);
            } else if (cur == '*' || cur == '/') {
                Node operator = new Node(3, Character.toString(cur));
                BST root = new BST(operator, null, null);
                order = order.add(root);
            } else if (cur == '^') {
                Node operator = new Node(2, Character.toString(cur));
                BST root = new BST(operator, null, null);
                order = order.add(root);
            }    
        }
        return order;
    }
    
   /*
    * simplifies the given eqn and then returns the simplified version.
    *
    * @Exception - throws an exception if the equation cannot be computated 
    * of if the quations is incorrectly parenthesed
    * @param eqn - a math equation
    * @return string - a simplified version of the given math equation
    */
    public static String simplify(String eqn) throws Exception{
        String subEqn = "";
        for (int i = 0; i < eqn.length(); i++) {
            if (eqn.charAt(i) == ')') {
                return Double.toString(solve(toBinaryTree(subEqn))) + eqn.substring(i + 1);                
            } else if (eqn.charAt(i) == '('){
                eqn = eqn.substring(0, i) + simplify(eqn.substring(i + 1));
                i--;
            } else if (i != eqn.length() - 1){
                subEqn += eqn.charAt(i);
            } else {
                throw new Exception("Missing a closing parenthese");
            }
        }
        return subEqn;
    }
    
   /*
    * solves the given equation inside the BST object
    *
    * @Exception - throws an exception if there is no BST object or if 
    * the children of the parent node cannot be solved
    * @param root - a part of the overall equation that is being solved
    * @return double - returns the answer to the equation in the given root
    */
    public static double solve(BST root) throws Exception {
        if (root.getCurrent() == null) {
            throw new Exception("Missing an operand");
        }
        Node current = root.getCurrent();
        if (current.priority == 0) {
            return Double.parseDouble(current.val);
        } else if (current.val.equals("+")) {
            return solve(root.getLeft()) + solve(root.getRight());
        } else if (current.val.equals("-")) {
            return solve(root.getLeft()) - solve(root.getRight());
        } else if (current.val.equals("*")) {
            return solve(root.getLeft()) * solve(root.getRight());
        } else if (current.val.equals("/")) {
            if (solve(root.getRight()) == 0) {
                throw new Exception("cannot divide by zero");
            }
            return solve(root.getLeft()) / solve(root.getRight());
        } else if (current.val.equals("^")) {
            return Math.pow(solve(root.getLeft()),solve(root.getRight()));
        } else if (current.val.equals("sin")) {
            return Math.sin(solve(root.getRight()));
        } else if (current.val.equals("cos")) {
            return Math.cos(solve(root.getRight()));
        } else if (current.val.equals("tan")) {
            return Math.tan(solve(root.getRight()));
        } else if (current.val.equals("cot")) {
            return 1/Math.tan(solve(root.getRight()));
        } else if (current.val.equals("ln")) {
            double num = Double.parseDouble(root.getRight().getCurrent().val);
            if (num < 0) {
                throw new Exception("cannot evaluate imaginary numbers.");
            } else {
                return Math.log(solve(root.getRight()));
            }
        } else if (current.val.equals("log10") || current.val.equals("log")) {
            double num = Double.parseDouble(root.getRight().getCurrent().val);
            if (num < 0) {
                throw new Exception("cannot evaluate imaginary numbers.");
            } else {
                return Math.log10(solve(root.getRight()));
            }
        } else {
            throw new Exception("Not a valid operand or function.");
        }
    }
    
   /*
    * checks that the given eqn has all the needed parentheses and that there
    * are no numbers in invalid places.
    *
    * @Exception - throws an exception if the method finds an error with 
    * the given eqn
    * @param eqn - the equation that is being checked.
    */
    public static void checkValidity(String eqn) throws Exception {
        boolean pass = true;
        int parenths = 0;
        if (eqn.charAt(0) == '(') {
            parenths++;
        } else if (eqn.charAt(0) == ')') {
            pass = false;
        } else if (eqn.length() == 0) {
            eqn = "0";
        }
        for (int i = 1; i < eqn.length(); i++) {
            char prev = eqn.charAt(i-1);
            char cur = eqn.charAt(i);
            if (cur == '(') {
                parenths++;
                if (Character.isDigit(prev)) {
                    if (eqn.substring(0, i).length() >= 5) {
                        if (!eqn.substring(i-5, i).equals("log10")) {
                            pass = false;
                        }
                    } else {
                        pass = false;
                    } 
                }
            } else if (cur == ')') {
                parenths--;
                if (parenths < 0) {
                    pass = false;
                }
                if (i < eqn.length() - 1) {
                    if (Character.isDigit(eqn.charAt(i+1))) {
                        pass = false;
                    }
                }
            }
            if (i < eqn.length() - 1) {
                if (eqn.substring(i - 1, i + 1).equals("ln") && eqn.charAt(i + 1) != '(') {
                    pass = false;
                }
            }
            if (i < eqn.length() - 2) {
                if ((eqn.substring(i - 1, i + 2).equals("sin") 
                        || eqn.substring(i - 1, i + 2).equals("cos") 
                        || eqn.substring(i - 1, i + 2).equals("tan") 
                        || eqn.substring(i - 1, i + 2).equals("cot")) && eqn.charAt(i + 2) != '(') {
                    pass = false;
                }
            }
            if (i < eqn.length() - 4) {
                if (eqn.substring(i - 1, i + 4).equals("log10") && eqn.charAt(i + 4) != '(') {
                    pass = false;
                }
            }
        }
        if (!pass || parenths != 0) {
            throw new Exception("This is not a valid equation.");
        }
    }
}