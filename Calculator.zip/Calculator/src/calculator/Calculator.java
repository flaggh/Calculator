/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;
import java.util.*;
import java.io.*;

/**
 *
 * @author hayde
 */
public class Calculator {

    public static void main(String[] args) {
        simplify("a");
        System.out.println("1 + 1 * 1 = " + solve(simplify("1+1*1")));
        System.out.println("1 = " + solve(simplify("1")));
        System.out.println("1 * 1 - 1 = " + solve(simplify("1*1-1")));
        System.out.println("1 / 1.23 + 1 * 1 = " + solve(simplify("1/1.23+1*1")));
        System.out.println("3 ^ 2 = " + solve(simplify("3^2")));
        System.out.println("2 ^ 3 = " + solve(simplify("2^3")));
        System.out.println("1 / 1.23 + 1 * 2 ^ 0 = " + solve(simplify("1/1.23+1*2^0")));
    }
    
    public static BST simplify(String eqn) {
        BST order = new BST();
        if (eqn.matches(".*[a-z].*") || eqn.matches(".*[A-Z].*")) {
            System.out.println("This is not an equation.");
        } else {
            String val = "";
            while (eqn.length() > 0) {
                Character current = eqn.charAt(0);
                Character next = 'a';
                if (eqn.length() > 1) {
                    next = eqn.charAt(1);
                } 
                if (current == '(') {
                    // get everything in the parentheses
                } else if (Character.isDigit(current) || 
                                (current.equals('.') && !val.contains("."))) {
                    val += current;
                    if (!Character.isDigit(next) && 
                                !(next.equals('.') && !val.contains("."))) {
                        Node operand = new Node(1, val);
                        order = order.add(operand);
                        val = "";
                    }
                } else if (current == '+' || current == '-') {
                    Node operator = new Node(4, Character.toString(current));
                    order = order.add(operator);
                } else if (current == '*' || current == '/') {
                    Node operator = new Node(3, Character.toString(current));
                    order = order.add(operator);
                } else if (current == '^') {
                    Node operator = new Node(2, Character.toString(current));
                    order = order.add(operator);
                }
                if (eqn.length() > 1) {
                    eqn = eqn.substring(1);
                } else {
                    eqn = "";
                }
            }
        }
        return order;
    }
    
    public static double solve(BST root) {
        Node current = root.getCurrent();
        if (current.priority == 1) {
            return Double.parseDouble(current.val);
        } else if (current.val.equals("+")) {
            return solve(root.getLeft()) + solve(root.getRight());
        } else if (current.val.equals("-")) {
            return solve(root.getLeft()) - solve(root.getRight());
        } else if (current.val.equals("*")) {
            return solve(root.getLeft()) * solve(root.getRight());
        } else if (current.val.equals("/")) {
            return solve(root.getLeft()) / solve(root.getRight());
        } else if (current.val.equals("^")) {
            return Math.pow(solve(root.getLeft()),solve(root.getRight()));
        }
        return 0;
    }
    
}

class BST {
    private Node current;
    private BST left;
    private BST right;
    
    public BST(Node current, BST left, BST right) {
        this.current = current;
        this.left = left;
        this.right = right;
    }
    
    public BST() {}
    
    public BST getRight() {
        return right;
    }
    
    public BST getLeft() {
        return left;
    }
    
    public Node getCurrent() {
        return current;
    }
    
    public BST add(Node node) {
        if (current == null) {
            return new BST(node, null, null);
        } else if (current.priority <= node.priority) {
            return new BST(node, this, null);
        } else if (right == null) {
            BST newRight = new BST(node, null, null);
            return new BST(this.current, this.getLeft(), newRight);
        } else {
            right = right.add(node);
            return this;
        }
    }
    
    public String toString() {
        if (current == null) {
            return "";
        } else if (right == null && left == null) {
            return current.val;
        } else if (right == null) {
            return left.toString() + current.val; 
        } else if (left == null) {
            return current.val + right.toString();
        } else {
            return left.toString()+current.val+right.toString();
        }
    }
    
    public BST setRight(BST node) {
        right = node;
        return right;
    }
    
    public BST setLeft(BST node) {
        left = node;
        return left;
    }
}

class Node {
    public int priority;
    public String val;
    
    public Node(int priority, String val) {
        this.priority = priority;
        this.val = val;
    }
}
