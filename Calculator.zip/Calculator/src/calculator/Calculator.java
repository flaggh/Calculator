/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;
import java.util.*;
import java.io.*;

/**
 *
 * @author hayde
 */
public class Calculator {
    
    public static BST toBinaryTree(String eqn) throws Exception {
        BST order = new BST();
        String val = "";
        eqn = eqn.replace(" ", "");
        // retry
        char prev = 'a';
        for (int i = 0; i < eqn.length(); i++) {
            char cur = eqn.charAt(i);
            char next = 'a';
            if (i < eqn.length() - 1) {
                next = eqn.charAt(i + 1);
            }
            if (i > 0) {
                prev = eqn.charAt(i - 1);
            }
            if (cur == '(') {
                eqn = eqn.substring(0, i) + simplify(eqn.substring(i + 1));
                i--;
            } else if (cur == ')') {
                val = "";
            }  else if (Character.isLetter(cur) || val.contains("log")) {
                val += Character.toLowerCase(cur);
                if (eqn.length() < 2) {
                    val = "";
                } else if ((val.equals("sin") || val.equals("cos") || val.equals("tan") || val.equals("cot") || val.equals("ln") || val.equals("log10"))) {
                    Node operator = new Node(1, val);
                    BST root = new BST(operator, new BST(new Node(0, "0"), null, null), null);
                    order = order.add(root);
                    val = "";
                } else if (val.length() == 5){
                    throw new Exception();
                }
            }   else if (Character.isDigit(cur) || 
                            (cur == '.' && !val.contains("."))) {
                val += cur;
                if (!Character.isDigit(next) && 
                            !(next == '.' && !val.contains("."))) {
                    Node operand = new Node(0, val);
                    BST root = new BST(operand, null, null);
                    order = order.add(root);
                    val = "";
                }
            } else if (cur == '-' && !Character.isDigit(prev)) {
                if (val.contains("-")) {
                    val = "";
                } else {
                    val += cur;
                }
            } else if (cur == '+' || cur == '-') {
                Node operator = new Node(4, Character.toString(cur));
                BST root = new BST(operator, null, null);
                order = order.add(root);
            } else if (cur == '*' || cur == '/') {
                Node operator = new Node(3, Character.toString(cur));
                BST root = new BST(operator, null, null);
                order = order.add(root);
            } else if (cur == '^') {
                Node operator = new Node(2, Character.toString(cur));
                BST root = new BST(operator, null, null);
                order = order.add(root);
            }    
        }
        return order;
    }
    
    public static String simplify(String eqn) throws Exception{
        String subEqn = "";
        for (int i = 0; i < eqn.length(); i++) {
            if (eqn.charAt(i) == ')') {
                return Double.toString(solve(toBinaryTree(subEqn))) + eqn.substring(i + 1);                
            } else if (eqn.charAt(i) == '('){
                eqn = eqn.substring(0, i) + simplify(eqn.substring(i + 1));
                i--;
            } else if (i != eqn.length() - 1){
                subEqn += eqn.charAt(i);
            } else {
                throw new Exception("Solve");
            }
        }
        return subEqn;
    }
    
    public static double solve(BST root) throws Exception {
        if (root.getCurrent() == null) {
            throw new ArithmeticException("Not a valid Equation.");
        }
        Node current = root.getCurrent();
        if (current.priority == 0) {
            return Double.parseDouble(current.val);
        } else if (current.val.equals("+")) {
            return solve(root.getLeft()) + solve(root.getRight());
        } else if (current.val.equals("-")) {
            return solve(root.getLeft()) - solve(root.getRight());
        } else if (current.val.equals("*")) {
            return solve(root.getLeft()) * solve(root.getRight());
        } else if (current.val.equals("/")) {
            if (solve(root.getRight()) == 0) {
                throw new Exception();
            }
            return solve(root.getLeft()) / solve(root.getRight());
        } else if (current.val.equals("^")) {
            return Math.pow(solve(root.getLeft()),solve(root.getRight()));
        } else if (current.val.equals("sin")) {
            return Math.sin(solve(root.getRight()));
        } else if (current.val.equals("cos")) {
            return Math.cos(solve(root.getRight()));
        } else if (current.val.equals("tan")) {
            return Math.tan(solve(root.getRight()));
        } else if (current.val.equals("cot")) {
            return 1/Math.tan(solve(root.getRight()));
        } else if (current.val.equals("ln")) {
            return Math.log(solve(root.getRight()));
        } else if (current.val.equals("log10")) {
            return Math.log10(solve(root.getRight()));
        } else {
            throw new Exception();
        }
    }
    
    public static void checkValidity(String eqn) throws Exception {
        boolean pass = true;
        int parenths = 0;
        if (eqn.charAt(0) == '(') {
            parenths++;
        } else if (eqn.charAt(0) == ')') {
            pass = false;
        }
        for (int i = 1; i < eqn.length(); i++) {
            char prev = eqn.charAt(i-1);
            char cur = eqn.charAt(i);
            if (cur == '(') {
                parenths++;
                if (Character.isDigit(prev)) {
                    if (eqn.substring(0, i).length() >= 5) {
                        if (!eqn.substring(i-5, i).equals("log10")) {
                            pass = false;
                        }
                    } else {
                        pass = false;
                    } 
                }
            } else if (cur == ')') {
                parenths--;
                if (parenths < 0) {
                    pass = false;
                }
                if (i < eqn.length() - 1) {
                    if (Character.isDigit(eqn.charAt(i+1))) {
                        pass = false;
                    }
                }
            }
            if (i < eqn.length() - 1) {
                if (eqn.substring(i - 1, i + 1).equals("ln") && eqn.charAt(i + 1) != '(') {
                    pass = false;
                }
            }
            if (i < eqn.length() - 2) {
                if ((eqn.substring(i - 1, i + 2).equals("sin") 
                        || eqn.substring(i - 1, i + 2).equals("cos") 
                        || eqn.substring(i - 1, i + 2).equals("tan") 
                        || eqn.substring(i - 1, i + 2).equals("cot")) && eqn.charAt(i + 2) != '(') {
                    pass = false;
                }
            }
            if (i < eqn.length() - 4) {
                if (eqn.substring(i - 1, i + 4).equals("log10") && eqn.charAt(i + 4) != '(') {
                    pass = false;
                }
            }
        }
        if (!pass || parenths != 0) {
            throw new Exception();
        }
    }
}