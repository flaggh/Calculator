/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package calculator;

import java.util.*;
import java.io.*;

/**
 *
 * @author hayde
 */
public class Main {
    
    public static void main(String[] args) throws Exception {
//        simplify("a");
//        System.out.println("1 + 1 * 1 = " + solve(toBinaryTree("1+1*1")));
//        System.out.println("1 = " + solve(toBinaryTree("1")));
//        System.out.println("1 * 1 - 1 = " + solve(toBinaryTree("1*1-1")));
//        System.out.println("1 / 1.23 + 1 * 1 = " + solve(toBinaryTree("1/1.23+1*1")));
//        System.out.println("3 ^ 2 = " + solve(toBinaryTree("3^2")));
//        System.out.println("2 ^ 3 = " + solve(toBinaryTree("2^3")));
//        System.out.println("1 / 1.23 + 1 * 2 ^ 0 = " + solve(toBinaryTree("1/1.23+1*2^0")));
//        System.out.println("(1 + 1) = " + solve(toBinaryTree("(1+1)")));
//        System.out.println("(1 + 1) * 2 = " + solve(toBinaryTree("(1+1)*2")));
//        System.out.println("sin(1) = " + solve(toBinaryTree("sin(1)")));
//        System.out.println("cos(1) = " + solve(toBinaryTree("cos(1)")));
//        System.out.println("tan(1) = " + solve(toBinaryTree("tan(1)")));
//        System.out.println("-1 = " + solve(toBinaryTree("-1")));
//        System.out.println("1 / -1 = " + solve(toBinaryTree("1/-1")));
//        System.out.println("ln(1) = " + solve(toBinaryTree("ln(1)")));
//        System.out.println("ln(1) = " + solve(toBinaryTree("log10(1)")));
//        System.out.println(solve(toBinaryTree("-5.78+-(4-2.23)+sin(0)*cos(1)/(1+tan(2*ln(-3+2*(1.23+99.111))))")));
        Scanner scan = new Scanner(System.in);
        while (true) {
            System.out.print("Please enter an equation.(type 'quit' to stop.)");
            String eqn = scan.nextLine();
            if (eqn.equals("quit")) {
                break;
            }
            try {
                Calculator.checkValidity(eqn);
                double ans = Calculator.solve(Calculator.toBinaryTree(eqn));
                System.out.println(eqn + " = " + ans);
            } catch (Exception e) {
                System.out.println(eqn + " is not a valid equation.");
            }
        }
    }
}
