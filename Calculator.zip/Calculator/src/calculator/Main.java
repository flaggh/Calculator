/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package calculator;

import java.util.*;
import java.io.*;

/**
 *
 * @author hayde
 */
public class Main {
    
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        while (true) {
            System.out.print("Please enter an equation.(type 'quit' to stop.)");
            String eqn = scan.nextLine();
            if (eqn.equals("quit")) {
                break;
            }
            try {
                Calculator.checkValidity(eqn);
                double ans = Calculator.solve(Calculator.toBinaryTree(eqn));
                System.out.println(eqn + " = " + ans);
            } catch (Exception e) {
                System.out.println(eqn + " is not a valid equation.");
            }
        }
    }
}
