/*
 * Name: Hayden Flagg
 * Class: CS 480 - Advanced Software Engineering
 * Assignment: Lab 3
 *
 * Honor Code: I pledge that this is my own original work and that I have not
 * received any unauthorized support with this lab.
 */
package calculator;

import java.util.*;
import java.io.*;

/**
 *
 * @author hayde
 */
public class Main {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        while (true) {
            System.out.print("Please enter an equation.(type 'quit' to stop.)");
            String eqn = scan.nextLine();
            if (eqn.equals("quit")) {
                break;
            }
            try {
                Calculator.checkValidity(eqn);
                double ans = Calculator.solve(Calculator.toBinaryTree(eqn));
                System.out.println(eqn + " = " + ans);
            } catch (Exception e) {
                System.out.println(e.getMessage());
                //System.out.println(eqn + " is not a valid equation.");
            }
        }
    }
}