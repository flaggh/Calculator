/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;

/**
 *
 * @author hayde
 */
public class BST {
    private Node current;
    private BST left;
    private BST right;
    
    public BST(Node current, BST left, BST right) {
        this.current = current;
        this.left = left;
        this.right = right;
    }
    
    public BST() {}
    
    public BST getRight() {
        return right;
    }
    
    public BST getLeft() {
        return left;
    }
    
    public Node getCurrent() {
        return current;
    }
    
    public BST add(BST root) {
        if (current == null && root.getCurrent().val.equals("-")) {
            BST zero = new BST(new Node(0, "0"), null, null);
            return new BST(root.getCurrent(), zero, null);
        } else if (current == null) {
            return root;
        } else if (root.getCurrent().priority == 1 && root.getCurrent().val.equals("-")) {
            root.setRight(this);
            return root;
        } else if (current.priority <= root.getCurrent().priority) {
            root.setLeft(this);
            return root;
        } else if (right == null) {
            return new BST(this.current, this.getLeft(), root);
        } else {
            right = right.add(root);
            return this;
        }
    }
    
    public String toString() {
        if (current == null) {
            return "";
        } else if (right == null && left == null) {
            return current.val;
        } else if (right == null) {
            return left.toString() + current.val; 
        } else if (left == null) {
            return current.val + right.toString();
        } else {
            return left.toString()+current.val+right.toString();
        }
    }
    
    public BST setRight(BST node) {
        right = node;
        return right;
    }
    
    public BST setLeft(BST node) {
        left = node;
        return left;
    }
}

class Node {
    public int priority;
    public String val;
    
    public Node(int priority, String val) {
        this.priority = priority;
        this.val = val;
    }
}

