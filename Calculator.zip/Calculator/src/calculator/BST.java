/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;

/**
 *
 * @author hayden flagg
 */

/*
 * a binary tree object that is used to solve equation in the correct order.
 *
 * Note for graders wondering why I didn't use java's binary tree class.
 * I had issues getting it to initialize
 */
class BST {
    // the current Node object that the tree is looking at
    private Node current;
    // the left child object of the current object
    private BST left;
    // the right child object of the current object
    private BST right;
    
    // constructor - creates the BST object while passing the info for all three
    // of its fields
    public BST(Node current, BST left, BST right) {
        this.current = current;
        this.left = left;
        this.right = right;
    }
    
    // a basic constructor that requires no input;
    public BST() {}
    
   /*
    * @return BST - return the right child of the BST
    */
    public BST getRight() {
        return right;
    }
    
    /*
    * @return BST - return the left child of the BST
    */
    public BST getLeft() {
        return left;
    }
    
    /*
    * @return Node - returns the Node object of the BST
    */
    public Node getCurrent() {
        return current;
    }
    
   /*
    * adds the given root to the BST
    *
    * @param root - a new BST that needs to be added to the BST using the root's
    * current Node's priority and the main BST object's current Node's priority
    * @return BST - returns the new BST that was created
    */
    public BST add(BST root) {
        if (current == null && root.getCurrent().val.equals("-")) {
            BST zero = new BST(new Node(0, "0"), null, null);
            return new BST(root.getCurrent(), zero, null);
        } else if (current == null) {
            return root;
        } else if (root.getCurrent().priority == 1 && root.getCurrent().val.equals("-")) {
            root.setRight(this);
            return root;
        } else if (current.priority <= root.getCurrent().priority) {
            root.setLeft(this);
            return root;
        } else if (right == null) {
            return new BST(this.current, this.getLeft(), root);
        } else {
            right = right.add(root);
            return this;
        }
    }
    
    // returns the BST object as a string.
    // This is basically used to print out the equation again.
    // only used in testing.
    public String toString() {
        if (current == null) {
            return "";
        } else if (right == null && left == null) {
            return current.val;
        } else if (right == null) {
            return left.toString() + current.val; 
        } else if (left == null) {
            return current.val + right.toString();
        } else {
            return left.toString()+current.val+right.toString();
        }
    }
     
   /*
    * sets the right node equal to the given node
    *
    * @param node - the new child BST
    * @return BST - the child BST that was just set
    */
    public BST setRight(BST node) {
        right = node;
        return right;
    }
    
    /*
    * sets the left node equal to the given node
    *
    * @param node - the new child BST
    * @return BST - the child BST that was just set
    */
    public BST setLeft(BST node) {
        left = node;
        return left;
    }
}

// An object used to give parts of an equation their priority and value which 
// should simulate an order of operations.
class Node {
    // the priority in which the Node should be solved
    public int priority;
    // the value of the node that will be used to solve the equation
    public String val;
    
    // constructs a Node object by passing in its fields as parameters.
    public Node(int priority, String val) {
        this.priority = priority;
        this.val = val;
    }
}

